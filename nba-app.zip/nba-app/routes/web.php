<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CommentsController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\PlayersController;
use App\Http\Controllers\TeamsController;
use App\Http\Controllers\VerifyController;
use App\Http\Middleware\AuthMiddleware;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/verify/{id}', [VerifyController::class, 'verify']);

Route::get('/signin', [AuthController::class, 'getSignIn']);
Route::get('/signup', [AuthController::class, 'getSignUp']);
Route::post('/signin', [AuthController::class, 'signIn']);
Route::post('/signup', [AuthController::class, 'signUp']);
Route::get('/signout', [AuthController::class, 'signOut']);

Route::post('/createcomment', [CommentsController::class, 'store'])->middleware('forbiden');

Route::get('/news', [NewsController::class, 'index']);
Route::get('/news/{id}', [NewsController::class, 'show']);
Route::get('/news/team/{name}', [NewsController::class, 'getNewsbyTeam']);
Route::get('/createnews', [NewsController::class, 'createNews']);
Route::post('create', [NewsController::class, 'store']);



Route::get('/', [TeamsController::class, 'index']);
Route::get('/{id}', [TeamsController::class, 'show'])->middleware(AuthMiddleware::class);
Route::get('/player/{id}', [PlayersController::class, 'show']);






