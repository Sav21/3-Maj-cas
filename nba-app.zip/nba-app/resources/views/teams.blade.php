@extends('layouts.default')
@include('layouts.sidebar')

@section('content')

<h1>Teams</h1>

@foreach ($teams as $team)
    
<ul>
    <li><a href="/{{$team->id}}">{{$team->id}}</a></li>
    <li><a href="/news/team/{{$team->name}}">{{$team->name}}</a></li>
    <li>{{$team->email}}</li>
    <li>News related to this team:</li>
    @foreach ($team->news as $news)
    <ul>
        <a href="/news/{{$news->id}}"><li>{{$news->title}}</li></a>
    </ul>
    @endforeach
    
</ul>


@endforeach
{{$teams}}

@endsection

