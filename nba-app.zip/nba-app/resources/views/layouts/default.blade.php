<!DOCTYPE html>
<html lang="en">
<head>
  @include('layouts.heading')
</head>
<body>

  @include('layouts.navbar')

  
  <main class="container mt-5 mb-5">
    @yield('content') 
  </main>
  
  
  @include('layouts.footer')
  
</body>
</html>