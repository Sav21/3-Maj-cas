@extends('layouts.default')

@section('content')

@foreach ($news as $singleNews)

<a href="/news/{{$singleNews->id}}"><h4>{{$singleNews->title}}</h4></a>
<p>{{$singleNews->content}}</p>
<h5>This article relates to this team:</h5>     
@foreach ($singleNews->teams as $team)
    <a href="/{{$team->id}}"><li>{{$team->name}}</li></a>
@endforeach
    <br>
@endforeach

{{$news}}

@endsection