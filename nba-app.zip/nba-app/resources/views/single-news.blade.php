@extends('layouts.default')

@section('content')

<h1>{{$singleNews->title}}</h1>

<p>{{$singleNews->content}}</p>


@endsection