@extends('layouts.default')


@section('content')

<form action="{{ url('create') }}" method="POST">
  @csrf
  <div class="mb-3">
    <label class="form-label">Title</label>
    <input type="text" class="form-control" name="title" required />
  </div>
  <div class="mb-3">
    <label class="form-label">Body</label>
    <textarea type="text" name="content" class="form-control" required></textarea>
  </div>
</div>
<button type="submit" class="btn btn-primary">Post News</button>
<div class="mb-3">
  <label class="form-label">Teams</label>
  <select name="teams[]" multiple class="form-select">
    @foreach ($teams as $team)
    
    <option value="{{$team->id}}">{{$team->name}}</option>
      
    @endforeach
  </select>
</div>



</form>

@include('layouts.errors')
@include('layouts.session')

@endsection