<?php

namespace App\Http\Controllers;

use App\Models\News;
use App\Models\Team;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NewsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $news = News::latest()->paginate(4);

        return view('news', compact('news'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|min:5|max:255|string',
            'content' => 'required|min:20|max:5000|string',            
        ]);

        $news = new News();
        $user = User::find(Auth::user()->id);

        $news->title = $request->title;
        $news->content = $request->content;
        $news->user()->associate($user);
        $news->save();

        foreach($request->teams as $teamsId){
            $news->teams()->attach($teamsId);
        }

        return redirect('news')->with('status', 'Thank you for publishing article on www.nba.com');


    }
    

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $singleNews = News::find($id);
        return view('single-news', compact('singleNews'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function createNews() {
        $teams = Team::all();
        return view('createnews', compact('teams'));
    }

    public function getNewsbyTeam(string $teamName){
        $news = News::whereHas('teams', function($query) use ($teamName){
            $query->where('name', '=', $teamName);
        })->paginate(5);
        return view('news', compact('news'));
    }
}
