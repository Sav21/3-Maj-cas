<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class VerifyController extends Controller
{
    public function verify($id) {
        $user = User::findOrFail($id);
        $user->markEmailAsVerified();
        return redirect('/signin')->with('status', 'email verified!');
    }
}
