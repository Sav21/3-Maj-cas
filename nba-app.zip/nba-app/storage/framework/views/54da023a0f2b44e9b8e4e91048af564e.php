<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<h1>Teams</h1>

<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<ul>
    <li><a href="/<?php echo e($team->id); ?>"><?php echo e($team->id); ?></a></li>
    <li><a href="/news/team/<?php echo e($team->name); ?>"><?php echo e($team->name); ?></a></li>
    <li><?php echo e($team->email); ?></li>
    <li>News related to this team:</li>
    <?php $__currentLoopData = $team->news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
        <a href="/news/<?php echo e($news->id); ?>"><li><?php echo e($news->title); ?></li></a>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</ul>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($teams); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/teams.blade.php ENDPATH**/ ?>