<?php $__env->startSection('content'); ?>

<h1><?php echo e($team->name); ?></h1>

<ul>
    <li><?php echo e($team->email); ?></li>
    <li><?php echo e($team->address); ?></li>
    <li><?php echo e($team->city); ?></li>

</ul>
<h4>Players:</h4>

<?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
        <li><a href="/player/<?php echo e($player->id); ?>"><?php echo e($player->id); ?></a></li>
        <li><?php echo e($player->first_name); ?></li>
    </ul>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<form action="<?php echo e(url('/createcomment')); ?>" method="POST" class="mt-5">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label class="form-label">Enter your comment</label>
        <textarea type="text" class="form-control" name="body" required></textarea>
        <input type="hidden" name="team_id" value="<?php echo e($team->id); ?>">
    </div>
    <button type="submit" class="btn btn-primary">Post Comment</button>
</form>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/singleteam.blade.php ENDPATH**/ ?>