<?php $__env->startSection('content'); ?>

<h1><?php echo e($singleNews->title); ?></h1>

<p><?php echo e($singleNews->content); ?></p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/single-news.blade.php ENDPATH**/ ?>