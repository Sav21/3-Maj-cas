<?php if(session('status')): ?>
    <div class="alert alert-success">
      <?php echo e(session('status')); ?>

    </div>
<?php endif; ?><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/layouts/session.blade.php ENDPATH**/ ?>