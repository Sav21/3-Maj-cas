<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('layouts.heading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
  <main class="container mt-5 mb-5">
    <?php echo $__env->yieldContent('content'); ?> 
  </main>
  
  
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
</body>
</html><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/layouts/default.blade.php ENDPATH**/ ?>