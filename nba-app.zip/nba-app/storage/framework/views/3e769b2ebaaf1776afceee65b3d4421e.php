<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('create')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label">Title</label>
    <input type="text" class="form-control" name="title" required />
  </div>
  <div class="mb-3">
    <label class="form-label">Body</label>
    <textarea type="text" name="content" class="form-control" required></textarea>
  </div>
</div>
<button type="submit" class="btn btn-primary">Post News</button>
<div class="mb-3">
  <label class="form-label">Teams</label>
  <select name="teams[]" multiple class="form-select">
    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>



</form>

<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/createnews.blade.php ENDPATH**/ ?>