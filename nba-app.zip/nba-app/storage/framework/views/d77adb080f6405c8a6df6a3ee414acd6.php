<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleNews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<a href="/news/<?php echo e($singleNews->id); ?>"><h4><?php echo e($singleNews->title); ?></h4></a>
<p><?php echo e($singleNews->content); ?></p>
<h5>This article relates to this team:</h5>     
<?php $__currentLoopData = $singleNews->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/<?php echo e($team->id); ?>"><li><?php echo e($team->name); ?></li></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e($news); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/nba-app/resources/views/news.blade.php ENDPATH**/ ?>